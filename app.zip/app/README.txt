README FILE
TEXT BASED INFORMATION RETRIEVAL SYSTEM

Requirements-
You need python 2.x with NLTK package to run the application successfully

I. HOW TO RUN THE PROGRAM.

Windows
1. Extract the given zip file
2. Place the required corpus files in the corpus folder to search and retrive results.
3. Run the exe file named "WindowsFormsApplication1.exe"

The application returns the filenames containing the required search term.

The code is well commented and self explanatory
 






